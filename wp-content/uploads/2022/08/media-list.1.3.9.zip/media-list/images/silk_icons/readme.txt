Silk icon set 1.3
http://www.famfamfam.com/lab/icons/silk/

This work is licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]
